下面這份設計是專門為現在的架構（RPi4 + faster-whisper + rule-first + LLM fallback + MQTT dispatch）量身設計的。
* 架構設計
* 插入關鍵點決策
* 技術選型
* 實作規格
* 發包給 AI-agent 的執行計畫（PLAN）
* 可驗收的 TODO 清單

================

# 一、設計目標（Design Goals）

## 硬限制

* RPi4 CPU already busy（ASR + LLM）
* 不可明顯增加延遲
* 不可引入重量級依賴（例如完整 ELK）

## 軟目標

* 能量化系統行為
* 能統計 fallback 比例
* 能分析 latency 分布
* 能分析錯誤類型
* 能離線分析（pandas）

---

# 二、整體 Metrics 架構

採用：

> In-memory Aggregator + Append-only JSONL Log

不使用資料庫（先不要）。
不使用 Prometheus（未來可加）。

---

## 架構圖

```text
Request
  ↓
[Metrics Context Start]
  ↓
ASR
  ↓
Intent (rule)
  ↓
LLM (optional)
  ↓
Validator
  ↓
Dispatch
  ↓
[Metrics Context End → flush JSONL]
```

---

# 三、Metrics 分兩層

## Layer 1：即時聚合器（RAM）

用途：

* 快速統計
* 不阻塞
* O(1) 操作

儲存：

* counters
* total latency
* fallback 次數
* success 次數

---

## Layer 2：結構化事件日誌（JSONL）

每一筆 request 一行：

```json
{
  "timestamp": 1710000000,
  "asr_latency": 0.82,
  "intent_stage": "keyword_only",
  "llm_used": true,
  "llm_latency": 0.41,
  "llm_success": true,
  "final_action": "off",
  "final_target": "light01",
  "total_latency": 1.34,
  "error_type": null
}
```

優點：

* append-only
* crash safe
* pandas 直接讀
* 可畫圖
* 不影響主線程

---

# 四、專案的關鍵插入點（非常重要）

以下是你必須插入 metrics 的位置。

---

## 1. WebSocket 收到音訊

紀錄：

* request_id
* start_timestamp

用途：

* 計算 end-to-end latency

---

## 2. ASR 完成

紀錄：

* asr_latency
* asr_text_length
* asr_empty (bool)

---

## 3. Keyword Intent 解析後

紀錄：

* keyword_action_found (bool)
* keyword_target_found (bool)

---

## 4. LLM 呼叫前後

紀錄：

* llm_called (bool)
* llm_latency
* llm_success (bool)
* llm_target_valid (bool)

---

## 5. Validator

紀錄：

* validator_pass (bool)
* reject_reason

---

## 6. Dispatch

紀錄：

* dispatch_type (mqtt / http)
* dispatch_success (bool)

---

## 7. Request 結束

計算：

* total_latency

然後 flush 一筆 JSONL。

---

# 五、核心 Metrics 模組設計規格

---

## 檔案結構

```text
metrics/
    metrics.py
    context.py
    logger.py
```

---

## 五-1. MetricsContext（每請求一個）

```python
class MetricsContext:
    def __init__(self, request_id):
        self.request_id = request_id
        self.start_time = time.time()
        self.data = {}
```

提供方法：

* mark_stage(name, value)
* set_flag(key, bool)
* record_latency(key, seconds)
* finalize()

---

## 五-2. Aggregator（全域）

```python
class MetricsAggregator:
    def __init__(self):
        self.total_requests = 0
        self.llm_calls = 0
        self.llm_success = 0
        self.keyword_success = 0
        self.total_latency = 0
```

方法：

* record(context)
* snapshot() → dict

---

## 五-3. JSONL Writer（非同步）

必須：

* 使用 background thread
* queue.Queue()
* append-only 寫入
* flush interval 1~2 秒

不能：

* 每次都 open/close
* 每次 fsync

---

# 六、插入策略（避免污染原本邏輯）

不要在每個 function 裡寫 metrics。

而是：

### 使用 context object 傳遞

例如：

```python
ctx = MetricsContext(request_id)

ctx.record_latency("asr", asr_time)
ctx.set_flag("llm_used", True)

metrics_aggregator.record(ctx)
```

不要讓 metrics 侵入業務邏輯。

---

# 七、AI Agent 發包 PLAN

這段你可以直接丟給 AI agent。

---

## PHASE 1：基礎框架

* 建立 metrics 模組
* 實作 MetricsContext
* 實作 MetricsAggregator
* 實作 JSONL async writer
* 單元測試(模擬 1000 次 request)

驗收條件：

* 不拋例外
* CPU 使用 < 3%
* 無 blocking

---

## PHASE 2：插入 ASR / Intent / LLM

* 在 ASR stage 插入 latency 計算
* 在 keyword parser 插入命中標記
* 在 LLM 前後插入 latency
* 在 request end flush JSON

驗收條件：

* log file 正確生成
* 不影響語音流程

---

## PHASE 3：簡易分析工具

新增：

```bash
python analyze_metrics.py
```

輸出：

* 平均 ASR latency
* LLM fallback ratio
* LLM success rate
* 平均 total latency

可使用常用的 pandas來分析。
