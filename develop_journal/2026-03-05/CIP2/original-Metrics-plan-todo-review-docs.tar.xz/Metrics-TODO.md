# TODO 清單

## 必做

* [ ] 建立 metrics 模組
* [ ] request lifecycle context
* [ ] async JSONL writer
* [ ] 插入 ASR latency
* [ ] 插入 LLM latency
* [ ] 插入 keyword 命中率
* [ ] 插入 total latency
* [ ] crash-safe 測試
* [ ] 壓力測試（連續 200 次）

## 可選

* [ ] 每日 log rotation
* [ ] 壓縮舊 log
* [ ] CLI 統計工具
* [ ] Prometheus exporter（未來）

---

# A. 最重要的設計決策（請務必堅持）

1. metrics 不能影響主流程
2. 不可同步寫檔
3. 不可在 ASR loop 裡做重運算
4. 不可引入大型依賴
5. context 必須 request-scoped

---

# B. 當這套上線後你會得到什麼？

你將能回答：

* LLM 真的有用嗎？
* fallback 佔幾 %？
* Whisper base 是否瓶頸？
* end-to-end latency 有沒有超過 1.5 秒？
* 哪種指令最容易失敗？

然後你可以用數據決定：

* 要不要升級模型
* 要不要改 alias
* 要不要砍掉 LLM
* 要不要升級硬體

這才是真正的架構優化。

================

